Cocoon Blocks
===================================

Cocoon Blocksは、Cocoonテーマに組み込まれたブロックエディター（Gutenberg）専用のブロック集です。

Cocoonテーマの詳細はURLを参照してください。
https://wp-cocoon.com/


プラグインライセンス
----------
Cocoon Blocksプラグインは、100％GPLです。

Cocoon Blocksに含まれているPHP、画像、JavaScript、CSS（スキン含む）等のすべてをGPLとして公開します（100%GPL）。
Cocoon Blocksの再配布もしくは、Cocoonを基盤として作成したテーマを配布する場合は、配布物すべて（PHP、JavaScript、CSS、画像、その他同梱物）をGPLとして公開してください（100％GPL：無料、有料問わず）。


GNU General Public License
http://www.gnu.org/licenses/gpl-2.0.html

開発者
------
わいひら： [yhira](https://github.com/yhira)
