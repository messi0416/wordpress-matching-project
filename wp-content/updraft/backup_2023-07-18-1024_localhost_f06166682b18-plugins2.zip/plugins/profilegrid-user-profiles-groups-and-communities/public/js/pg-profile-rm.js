(function( $ ) {
	'use strict';
       
      var href =  $('#pg_rm_registration_tab a').attr('href');   
      
        $('#pg_rm_registration_tab a').attr('href',href +'#pg_rm_registration_tab');
})(jQuery);